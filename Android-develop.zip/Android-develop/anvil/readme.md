# Anvil Compiler Plugins
Module home to all code generators used for DI, feature flagging and much more.

## Who can help you better understand this feature?
- Aitor Viana

## More information
NA