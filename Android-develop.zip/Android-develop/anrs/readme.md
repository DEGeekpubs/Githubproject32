# ANR and Crash Library
Library that contains code related to detection and reporting of ANRs and Crashes.

## Who can help you better understand this feature?
- Aitor Viana

## More information
NA