# App Build Config
Simple library to get all necessary build information, like version, applicationID, flavor and much more.

## Who can help you better understand this feature?
- Aitor Viana

## More information
NA