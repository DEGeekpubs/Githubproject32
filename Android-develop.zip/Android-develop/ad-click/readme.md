# AdClick
Implementation of the Ad Click feature. This is used to measure ad conversions only when they are required.

## Who can help you better understand this feature?
- Ana Capatina

## More information
- [Asana: Tech Design - generic](https://app.asana.com/0/481882893211075/1202389492148020/f)
- [Asana: Tech Design - Android specific implementation](https://app.asana.com/0/481882893211075/1202378654573683/f)