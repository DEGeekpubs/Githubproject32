output.bookmarks = {
    domains: ["https://www.example.com", "fill.dev"],
    folders: ["sync"],
}
