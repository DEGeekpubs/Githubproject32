output.bookmarks = {
    titles: ["Example Domain", "Test Autofill", "DuckDuckGo — Privacy, simplified."],
    folders: ["sync"],
}
